﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_U14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double input1 = 0;
        double input2 = 0;
        double input3 = 0;

        #region Rectangle
        public double Rectangle()
        {
            double answer = input1 * input2;
            return answer;
        }
        #endregion

        #region Triangle
        public double Triangle()
        {
            double answer = input1 * input2 / 2;
            return answer;
        }
        #endregion

        #region Circle
        public double Circle()
        {
            double answer = input1 * input1 * 3.14;
            return answer;
        }
        #endregion

        #region Heron Triangle
        public double Heron()
        {
            double input1 = Convert.ToDouble(textBox5.Text);
            double input2 = Convert.ToDouble(textBox6.Text);
            double input3 = Convert.ToDouble(textBox7.Text);

            double S = (input1 + input2 + input3) / 2;
            double Answer1 = Math.Sqrt(S * (S - input1) * (S - input2) * (S - input3));
            double lblans4 = Answer1;

            lblans4 = Math.Round(lblans4, 2);
            return lblans4;
        }
        #endregion


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnarea_Click(object sender, EventArgs e)
        {
            string inputlength = textBox1.Text;
            string inputwidth = textBox2.Text;
            bool parsed = double.TryParse(inputlength, out input1);
            if (!parsed)
            {
                MessageBox.Show("enter in the correct format");
                
            }
            bool parsed2 = double.TryParse(inputwidth, out input2);
            if (!parsed2)
            {
                MessageBox.Show("enter in the correct format");

            }
            lbl2.Text = Rectangle().ToString(); 

 
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void lblWidth_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            tab.SelectTab("tbRectangle");
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void lblBase_Click(object sender, EventArgs e)
        {

        }

        private void tabCircle_Click(object sender, EventArgs e)
        {
         
        }

        private void btnTriangleTab_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbTriangle");
        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void btnCircleTab_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbCircle");
        }

        private void btnHeronTriangleTab_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbHeronTri");
        }

        private void btnHelpFile_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbHelpPage");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnhome5_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbHomePage");
        }

        private void tbRectangle_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string inputbase = textBox3.Text;
            string inputheight = textBox4.Text;
            bool parsed = double.TryParse(inputbase, out input1);
            if (!parsed)
            {
                MessageBox.Show("enter in the correct format");

            }
            bool parsed2 = double.TryParse(inputheight, out input2);
            if (!parsed2)
            {
                MessageBox.Show("enter in the correct format");

            }
            lblTriangleAns.Text = Triangle().ToString();
        }

        private void btnCalcCircle_Click(object sender, EventArgs e)
        {
            string inputradius = txtbxRadius.Text;
           
            bool parsed = double.TryParse(inputradius, out input1);
            if (!parsed)
            {
                MessageBox.Show("enter in the correct format");

            }

            lblCircleAns.Text = Circle().ToString();
        }

        private void lblCircleAns_Click(object sender, EventArgs e)
        {

        }

        private void lblans4_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcHeron_Click(object sender, EventArgs e)
        {
            string inputlength1 = textBox5.Text;
            string inputlength2 = textBox6.Text;
            string inputlength3 = textBox7.Text;
            bool parsed = double.TryParse(inputlength1, out input1);
            if (!parsed)
            {
                MessageBox.Show("enter in the correct format");

            }
            bool parsed2 = double.TryParse(inputlength2, out input2);
            if (!parsed2)
            {
                MessageBox.Show("enter in the correct format");

            }
            bool parsed3 = double.TryParse(inputlength3, out input3);
            if (!parsed3)
            {
                MessageBox.Show("enter in the correct format");

            }

            lblans4.Text = Triangle().ToString();
        }

        private void btnbacktohome2_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbHomePage");
        }

        private void btnBacktoHome3_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbHomePage");
        }

        private void btnBacktoHome4_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbHomePage");
        }

        private void btnBacktoHome_Click(object sender, EventArgs e)
        {
            tab.SelectTab("tbHomePage");
        }
    }
}
