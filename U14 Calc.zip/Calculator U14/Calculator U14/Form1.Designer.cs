﻿namespace Calculator_U14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tab = new System.Windows.Forms.TabControl();
            this.tbHomePage = new System.Windows.Forms.TabPage();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnHelpFile = new System.Windows.Forms.Button();
            this.btnHeronTriangleTab = new System.Windows.Forms.Button();
            this.btnCircleTab = new System.Windows.Forms.Button();
            this.btnTriangleTab = new System.Windows.Forms.Button();
            this.lblChoice = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.btnRectangleTab = new System.Windows.Forms.Button();
            this.tbRectangle = new System.Windows.Forms.TabPage();
            this.lblWidth = new System.Windows.Forms.Label();
            this.lblLength = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.btnarea = new System.Windows.Forms.Button();
            this.lbl2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tbTriangle = new System.Windows.Forms.TabPage();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblTriangleAns = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.lblHeight = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblBase = new System.Windows.Forms.Label();
            this.lblTrianglPage = new System.Windows.Forms.Label();
            this.tbCircle = new System.Windows.Forms.TabPage();
            this.btnCalcCircle = new System.Windows.Forms.Button();
            this.lblCircleAns = new System.Windows.Forms.Label();
            this.txtbxRadius = new System.Windows.Forms.TextBox();
            this.lblRadius = new System.Windows.Forms.Label();
            this.lblCircleTitle = new System.Windows.Forms.Label();
            this.lblCirclePage = new System.Windows.Forms.Label();
            this.tbHeronTri = new System.Windows.Forms.TabPage();
            this.lblans4 = new System.Windows.Forms.Label();
            this.lblHrnLen3 = new System.Windows.Forms.Label();
            this.lblHrnLen2 = new System.Windows.Forms.Label();
            this.lblHrnLen1 = new System.Windows.Forms.Label();
            this.lblHrntriTitle = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.btnCalcHeron = new System.Windows.Forms.Button();
            this.tbHelpPage = new System.Windows.Forms.TabPage();
            this.btnhome5 = new System.Windows.Forms.Button();
            this.lblStep4 = new System.Windows.Forms.Label();
            this.lblStep3 = new System.Windows.Forms.Label();
            this.lblStep2 = new System.Windows.Forms.Label();
            this.lblStep1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnbacktohome2 = new System.Windows.Forms.Button();
            this.btnBacktoHome3 = new System.Windows.Forms.Button();
            this.btnBacktoHome4 = new System.Windows.Forms.Button();
            this.btnBacktoHome = new System.Windows.Forms.Button();
            this.tab.SuspendLayout();
            this.tbHomePage.SuspendLayout();
            this.tbRectangle.SuspendLayout();
            this.tbTriangle.SuspendLayout();
            this.tbCircle.SuspendLayout();
            this.tbHeronTri.SuspendLayout();
            this.tbHelpPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tbHomePage);
            this.tab.Controls.Add(this.tbRectangle);
            this.tab.Controls.Add(this.tbTriangle);
            this.tab.Controls.Add(this.tbCircle);
            this.tab.Controls.Add(this.tbHeronTri);
            this.tab.Controls.Add(this.tbHelpPage);
            this.tab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab.Location = new System.Drawing.Point(0, 0);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(502, 355);
            this.tab.TabIndex = 0;
            // 
            // tbHomePage
            // 
            this.tbHomePage.Controls.Add(this.btnExit);
            this.tbHomePage.Controls.Add(this.btnHelpFile);
            this.tbHomePage.Controls.Add(this.btnHeronTriangleTab);
            this.tbHomePage.Controls.Add(this.btnCircleTab);
            this.tbHomePage.Controls.Add(this.btnTriangleTab);
            this.tbHomePage.Controls.Add(this.lblChoice);
            this.tbHomePage.Controls.Add(this.lbl1);
            this.tbHomePage.Controls.Add(this.btnRectangleTab);
            this.tbHomePage.Location = new System.Drawing.Point(4, 22);
            this.tbHomePage.Name = "tbHomePage";
            this.tbHomePage.Padding = new System.Windows.Forms.Padding(3);
            this.tbHomePage.Size = new System.Drawing.Size(494, 329);
            this.tbHomePage.TabIndex = 0;
            this.tbHomePage.Text = "Home";
            this.tbHomePage.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(212, 280);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnHelpFile
            // 
            this.btnHelpFile.Location = new System.Drawing.Point(162, 242);
            this.btnHelpFile.Name = "btnHelpFile";
            this.btnHelpFile.Size = new System.Drawing.Size(178, 23);
            this.btnHelpFile.TabIndex = 6;
            this.btnHelpFile.Text = "How to Use the Calculator";
            this.btnHelpFile.UseVisualStyleBackColor = true;
            this.btnHelpFile.Click += new System.EventHandler(this.btnHelpFile_Click);
            // 
            // btnHeronTriangleTab
            // 
            this.btnHeronTriangleTab.Location = new System.Drawing.Point(325, 200);
            this.btnHeronTriangleTab.Name = "btnHeronTriangleTab";
            this.btnHeronTriangleTab.Size = new System.Drawing.Size(90, 23);
            this.btnHeronTriangleTab.TabIndex = 5;
            this.btnHeronTriangleTab.Text = "Heron Triangle";
            this.btnHeronTriangleTab.UseVisualStyleBackColor = true;
            this.btnHeronTriangleTab.Click += new System.EventHandler(this.btnHeronTriangleTab_Click);
            // 
            // btnCircleTab
            // 
            this.btnCircleTab.Location = new System.Drawing.Point(82, 200);
            this.btnCircleTab.Name = "btnCircleTab";
            this.btnCircleTab.Size = new System.Drawing.Size(90, 23);
            this.btnCircleTab.TabIndex = 4;
            this.btnCircleTab.Text = "Circle";
            this.btnCircleTab.UseVisualStyleBackColor = true;
            this.btnCircleTab.Click += new System.EventHandler(this.btnCircleTab_Click);
            // 
            // btnTriangleTab
            // 
            this.btnTriangleTab.Location = new System.Drawing.Point(325, 140);
            this.btnTriangleTab.Name = "btnTriangleTab";
            this.btnTriangleTab.Size = new System.Drawing.Size(90, 23);
            this.btnTriangleTab.TabIndex = 3;
            this.btnTriangleTab.Text = "Triangle";
            this.btnTriangleTab.UseVisualStyleBackColor = true;
            this.btnTriangleTab.Click += new System.EventHandler(this.btnTriangleTab_Click);
            // 
            // lblChoice
            // 
            this.lblChoice.AutoSize = true;
            this.lblChoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoice.Location = new System.Drawing.Point(159, 93);
            this.lblChoice.Name = "lblChoice";
            this.lblChoice.Size = new System.Drawing.Size(204, 16);
            this.lblChoice.TabIndex = 2;
            this.lblChoice.Text = "What would you like to calculate?";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(91, 33);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(315, 25);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "Welcome to the Area Calculator";
            // 
            // btnRectangleTab
            // 
            this.btnRectangleTab.Location = new System.Drawing.Point(82, 140);
            this.btnRectangleTab.Name = "btnRectangleTab";
            this.btnRectangleTab.Size = new System.Drawing.Size(90, 23);
            this.btnRectangleTab.TabIndex = 0;
            this.btnRectangleTab.Text = "Rectangle";
            this.btnRectangleTab.UseVisualStyleBackColor = true;
            this.btnRectangleTab.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // tbRectangle
            // 
            this.tbRectangle.Controls.Add(this.btnbacktohome2);
            this.tbRectangle.Controls.Add(this.lblWidth);
            this.tbRectangle.Controls.Add(this.lblLength);
            this.tbRectangle.Controls.Add(this.lbl3);
            this.tbRectangle.Controls.Add(this.btnarea);
            this.tbRectangle.Controls.Add(this.lbl2);
            this.tbRectangle.Controls.Add(this.textBox2);
            this.tbRectangle.Controls.Add(this.textBox1);
            this.tbRectangle.Location = new System.Drawing.Point(4, 22);
            this.tbRectangle.Name = "tbRectangle";
            this.tbRectangle.Padding = new System.Windows.Forms.Padding(3);
            this.tbRectangle.Size = new System.Drawing.Size(494, 329);
            this.tbRectangle.TabIndex = 1;
            this.tbRectangle.Text = "Rectangle";
            this.tbRectangle.UseVisualStyleBackColor = true;
            this.tbRectangle.Click += new System.EventHandler(this.tbRectangle_Click);
            // 
            // lblWidth
            // 
            this.lblWidth.AutoSize = true;
            this.lblWidth.Location = new System.Drawing.Point(153, 152);
            this.lblWidth.Name = "lblWidth";
            this.lblWidth.Size = new System.Drawing.Size(66, 13);
            this.lblWidth.TabIndex = 6;
            this.lblWidth.Text = "Enter Width:";
            this.lblWidth.Click += new System.EventHandler(this.lblWidth_Click);
            // 
            // lblLength
            // 
            this.lblLength.AutoSize = true;
            this.lblLength.Location = new System.Drawing.Point(148, 115);
            this.lblLength.Name = "lblLength";
            this.lblLength.Size = new System.Drawing.Size(71, 13);
            this.lblLength.TabIndex = 5;
            this.lblLength.Text = "Enter Length:";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(104, 25);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(334, 25);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Calculate the Area of a Rectangle";
            this.lbl3.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // btnarea
            // 
            this.btnarea.Location = new System.Drawing.Point(207, 192);
            this.btnarea.Name = "btnarea";
            this.btnarea.Size = new System.Drawing.Size(75, 23);
            this.btnarea.TabIndex = 3;
            this.btnarea.Text = "Calculate";
            this.btnarea.UseVisualStyleBackColor = true;
            this.btnarea.Click += new System.EventHandler(this.btnarea_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(175, 236);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(150, 13);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Your Answer is displayed Here";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(225, 149);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(225, 112);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            // 
            // tbTriangle
            // 
            this.tbTriangle.Controls.Add(this.btnBacktoHome3);
            this.tbTriangle.Controls.Add(this.btnCalculate);
            this.tbTriangle.Controls.Add(this.lblTriangleAns);
            this.tbTriangle.Controls.Add(this.textBox4);
            this.tbTriangle.Controls.Add(this.lblHeight);
            this.tbTriangle.Controls.Add(this.textBox3);
            this.tbTriangle.Controls.Add(this.lblBase);
            this.tbTriangle.Controls.Add(this.lblTrianglPage);
            this.tbTriangle.Location = new System.Drawing.Point(4, 22);
            this.tbTriangle.Name = "tbTriangle";
            this.tbTriangle.Padding = new System.Windows.Forms.Padding(3);
            this.tbTriangle.Size = new System.Drawing.Size(494, 329);
            this.tbTriangle.TabIndex = 2;
            this.tbTriangle.Text = "Triangle";
            this.tbTriangle.UseVisualStyleBackColor = true;
            this.tbTriangle.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(218, 196);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 6;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblTriangleAns
            // 
            this.lblTriangleAns.AutoSize = true;
            this.lblTriangleAns.Location = new System.Drawing.Point(176, 241);
            this.lblTriangleAns.Name = "lblTriangleAns";
            this.lblTriangleAns.Size = new System.Drawing.Size(148, 13);
            this.lblTriangleAns.TabIndex = 5;
            this.lblTriangleAns.Text = "Your Answer is displayed here";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(189, 158);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(135, 20);
            this.textBox4.TabIndex = 4;
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(142, 165);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(41, 13);
            this.lblHeight.TabIndex = 3;
            this.lblHeight.Text = "Height:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(186, 122);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(138, 20);
            this.textBox3.TabIndex = 2;
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Location = new System.Drawing.Point(146, 125);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(34, 13);
            this.lblBase.TabIndex = 1;
            this.lblBase.Text = "Base:";
            this.lblBase.Click += new System.EventHandler(this.lblBase_Click);
            // 
            // lblTrianglPage
            // 
            this.lblTrianglPage.AutoSize = true;
            this.lblTrianglPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrianglPage.Location = new System.Drawing.Point(93, 38);
            this.lblTrianglPage.Name = "lblTrianglPage";
            this.lblTrianglPage.Size = new System.Drawing.Size(315, 25);
            this.lblTrianglPage.TabIndex = 0;
            this.lblTrianglPage.Text = "Calculate the Area of a Triangle";
            // 
            // tbCircle
            // 
            this.tbCircle.Controls.Add(this.btnBacktoHome4);
            this.tbCircle.Controls.Add(this.btnCalcCircle);
            this.tbCircle.Controls.Add(this.lblCircleAns);
            this.tbCircle.Controls.Add(this.txtbxRadius);
            this.tbCircle.Controls.Add(this.lblRadius);
            this.tbCircle.Controls.Add(this.lblCircleTitle);
            this.tbCircle.Controls.Add(this.lblCirclePage);
            this.tbCircle.Location = new System.Drawing.Point(4, 22);
            this.tbCircle.Name = "tbCircle";
            this.tbCircle.Padding = new System.Windows.Forms.Padding(3);
            this.tbCircle.Size = new System.Drawing.Size(494, 329);
            this.tbCircle.TabIndex = 3;
            this.tbCircle.Text = "Circle";
            this.tbCircle.UseVisualStyleBackColor = true;
            this.tbCircle.Click += new System.EventHandler(this.tabCircle_Click);
            // 
            // btnCalcCircle
            // 
            this.btnCalcCircle.Location = new System.Drawing.Point(205, 153);
            this.btnCalcCircle.Name = "btnCalcCircle";
            this.btnCalcCircle.Size = new System.Drawing.Size(65, 46);
            this.btnCalcCircle.TabIndex = 5;
            this.btnCalcCircle.Text = "Calculate";
            this.btnCalcCircle.UseVisualStyleBackColor = true;
            this.btnCalcCircle.Click += new System.EventHandler(this.btnCalcCircle_Click);
            // 
            // lblCircleAns
            // 
            this.lblCircleAns.AutoSize = true;
            this.lblCircleAns.Location = new System.Drawing.Point(165, 202);
            this.lblCircleAns.Name = "lblCircleAns";
            this.lblCircleAns.Size = new System.Drawing.Size(152, 13);
            this.lblCircleAns.TabIndex = 4;
            this.lblCircleAns.Text = "Your Answer is Displayed Here";
            this.lblCircleAns.Click += new System.EventHandler(this.lblCircleAns_Click);
            // 
            // txtbxRadius
            // 
            this.txtbxRadius.Location = new System.Drawing.Point(164, 127);
            this.txtbxRadius.Name = "txtbxRadius";
            this.txtbxRadius.Size = new System.Drawing.Size(153, 20);
            this.txtbxRadius.TabIndex = 3;
            // 
            // lblRadius
            // 
            this.lblRadius.AutoSize = true;
            this.lblRadius.Location = new System.Drawing.Point(106, 130);
            this.lblRadius.Name = "lblRadius";
            this.lblRadius.Size = new System.Drawing.Size(43, 13);
            this.lblRadius.TabIndex = 2;
            this.lblRadius.Text = "Radius:";
            // 
            // lblCircleTitle
            // 
            this.lblCircleTitle.AutoSize = true;
            this.lblCircleTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCircleTitle.Location = new System.Drawing.Point(79, 34);
            this.lblCircleTitle.Name = "lblCircleTitle";
            this.lblCircleTitle.Size = new System.Drawing.Size(292, 25);
            this.lblCircleTitle.TabIndex = 1;
            this.lblCircleTitle.Text = "Calculate the Area of a Circle";
            // 
            // lblCirclePage
            // 
            this.lblCirclePage.AutoSize = true;
            this.lblCirclePage.Location = new System.Drawing.Point(130, 34);
            this.lblCirclePage.Name = "lblCirclePage";
            this.lblCirclePage.Size = new System.Drawing.Size(0, 13);
            this.lblCirclePage.TabIndex = 0;
            // 
            // tbHeronTri
            // 
            this.tbHeronTri.Controls.Add(this.btnBacktoHome);
            this.tbHeronTri.Controls.Add(this.lblans4);
            this.tbHeronTri.Controls.Add(this.lblHrnLen3);
            this.tbHeronTri.Controls.Add(this.lblHrnLen2);
            this.tbHeronTri.Controls.Add(this.lblHrnLen1);
            this.tbHeronTri.Controls.Add(this.lblHrntriTitle);
            this.tbHeronTri.Controls.Add(this.textBox7);
            this.tbHeronTri.Controls.Add(this.textBox6);
            this.tbHeronTri.Controls.Add(this.textBox5);
            this.tbHeronTri.Controls.Add(this.btnCalcHeron);
            this.tbHeronTri.Location = new System.Drawing.Point(4, 22);
            this.tbHeronTri.Name = "tbHeronTri";
            this.tbHeronTri.Padding = new System.Windows.Forms.Padding(3);
            this.tbHeronTri.Size = new System.Drawing.Size(494, 329);
            this.tbHeronTri.TabIndex = 4;
            this.tbHeronTri.Text = "Heron Triangle";
            this.tbHeronTri.UseVisualStyleBackColor = true;
            // 
            // lblans4
            // 
            this.lblans4.AutoSize = true;
            this.lblans4.Location = new System.Drawing.Point(182, 216);
            this.lblans4.Name = "lblans4";
            this.lblans4.Size = new System.Drawing.Size(148, 13);
            this.lblans4.TabIndex = 8;
            this.lblans4.Text = "Your Answer is displayed here";
            this.lblans4.Click += new System.EventHandler(this.lblans4_Click);
            // 
            // lblHrnLen3
            // 
            this.lblHrnLen3.AutoSize = true;
            this.lblHrnLen3.Location = new System.Drawing.Point(144, 167);
            this.lblHrnLen3.Name = "lblHrnLen3";
            this.lblHrnLen3.Size = new System.Drawing.Size(52, 13);
            this.lblHrnLen3.TabIndex = 7;
            this.lblHrnLen3.Text = "Length 3:";
            // 
            // lblHrnLen2
            // 
            this.lblHrnLen2.AutoSize = true;
            this.lblHrnLen2.Location = new System.Drawing.Point(144, 141);
            this.lblHrnLen2.Name = "lblHrnLen2";
            this.lblHrnLen2.Size = new System.Drawing.Size(52, 13);
            this.lblHrnLen2.TabIndex = 6;
            this.lblHrnLen2.Text = "Length 2:";
            // 
            // lblHrnLen1
            // 
            this.lblHrnLen1.AutoSize = true;
            this.lblHrnLen1.Location = new System.Drawing.Point(144, 115);
            this.lblHrnLen1.Name = "lblHrnLen1";
            this.lblHrnLen1.Size = new System.Drawing.Size(52, 13);
            this.lblHrnLen1.TabIndex = 5;
            this.lblHrnLen1.Text = "Length 1:";
            this.lblHrnLen1.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // lblHrntriTitle
            // 
            this.lblHrntriTitle.AutoSize = true;
            this.lblHrntriTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHrntriTitle.Location = new System.Drawing.Point(60, 32);
            this.lblHrntriTitle.Name = "lblHrntriTitle";
            this.lblHrntriTitle.Size = new System.Drawing.Size(379, 25);
            this.lblHrntriTitle.TabIndex = 4;
            this.lblHrntriTitle.Text = "Calculate the Area of a Heron Triangle";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(202, 164);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 3;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(202, 138);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 2;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(202, 112);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 1;
            // 
            // btnCalcHeron
            // 
            this.btnCalcHeron.Location = new System.Drawing.Point(211, 190);
            this.btnCalcHeron.Name = "btnCalcHeron";
            this.btnCalcHeron.Size = new System.Drawing.Size(75, 23);
            this.btnCalcHeron.TabIndex = 0;
            this.btnCalcHeron.Text = "Calculate";
            this.btnCalcHeron.UseVisualStyleBackColor = true;
            this.btnCalcHeron.Click += new System.EventHandler(this.btnCalcHeron_Click);
            // 
            // tbHelpPage
            // 
            this.tbHelpPage.Controls.Add(this.btnhome5);
            this.tbHelpPage.Controls.Add(this.lblStep4);
            this.tbHelpPage.Controls.Add(this.lblStep3);
            this.tbHelpPage.Controls.Add(this.lblStep2);
            this.tbHelpPage.Controls.Add(this.lblStep1);
            this.tbHelpPage.Controls.Add(this.label1);
            this.tbHelpPage.Location = new System.Drawing.Point(4, 22);
            this.tbHelpPage.Name = "tbHelpPage";
            this.tbHelpPage.Padding = new System.Windows.Forms.Padding(3);
            this.tbHelpPage.Size = new System.Drawing.Size(494, 329);
            this.tbHelpPage.TabIndex = 5;
            this.tbHelpPage.Text = "Help Page";
            this.tbHelpPage.UseVisualStyleBackColor = true;
            // 
            // btnhome5
            // 
            this.btnhome5.Location = new System.Drawing.Point(178, 245);
            this.btnhome5.Name = "btnhome5";
            this.btnhome5.Size = new System.Drawing.Size(122, 57);
            this.btnhome5.TabIndex = 5;
            this.btnhome5.Text = "Back to Home";
            this.btnhome5.UseVisualStyleBackColor = true;
            this.btnhome5.Click += new System.EventHandler(this.btnhome5_Click);
            // 
            // lblStep4
            // 
            this.lblStep4.AutoSize = true;
            this.lblStep4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStep4.Location = new System.Drawing.Point(10, 188);
            this.lblStep4.Name = "lblStep4";
            this.lblStep4.Size = new System.Drawing.Size(484, 20);
            this.lblStep4.TabIndex = 4;
            this.lblStep4.Text = "Step 4:Decide if you want to stop the Application or do another sum";
            // 
            // lblStep3
            // 
            this.lblStep3.AutoSize = true;
            this.lblStep3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStep3.Location = new System.Drawing.Point(9, 168);
            this.lblStep3.Name = "lblStep3";
            this.lblStep3.Size = new System.Drawing.Size(489, 20);
            this.lblStep3.TabIndex = 3;
            this.lblStep3.Text = "Step 3:Press Calculate and your Answer will be displayed On-Screen";
            // 
            // lblStep2
            // 
            this.lblStep2.AutoSize = true;
            this.lblStep2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStep2.Location = new System.Drawing.Point(8, 148);
            this.lblStep2.Name = "lblStep2";
            this.lblStep2.Size = new System.Drawing.Size(446, 20);
            this.lblStep2.TabIndex = 2;
            this.lblStep2.Text = "Step 2:Input the 1st input and then the 2nd and 3rd if required";
            // 
            // lblStep1
            // 
            this.lblStep1.AutoSize = true;
            this.lblStep1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStep1.Location = new System.Drawing.Point(8, 128);
            this.lblStep1.Name = "lblStep1";
            this.lblStep1.Size = new System.Drawing.Size(332, 20);
            this.lblStep1.TabIndex = 1;
            this.lblStep1.Text = "Step 1:Select the shape you want to calculate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(188, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Help Page";
            // 
            // btnbacktohome2
            // 
            this.btnbacktohome2.Location = new System.Drawing.Point(178, 268);
            this.btnbacktohome2.Name = "btnbacktohome2";
            this.btnbacktohome2.Size = new System.Drawing.Size(130, 41);
            this.btnbacktohome2.TabIndex = 7;
            this.btnbacktohome2.Text = "Back to Home";
            this.btnbacktohome2.UseVisualStyleBackColor = true;
            this.btnbacktohome2.Click += new System.EventHandler(this.btnbacktohome2_Click);
            // 
            // btnBacktoHome3
            // 
            this.btnBacktoHome3.Location = new System.Drawing.Point(201, 268);
            this.btnBacktoHome3.Name = "btnBacktoHome3";
            this.btnBacktoHome3.Size = new System.Drawing.Size(110, 41);
            this.btnBacktoHome3.TabIndex = 7;
            this.btnBacktoHome3.Text = "Back to Home";
            this.btnBacktoHome3.UseVisualStyleBackColor = true;
            this.btnBacktoHome3.Click += new System.EventHandler(this.btnBacktoHome3_Click);
            // 
            // btnBacktoHome4
            // 
            this.btnBacktoHome4.Location = new System.Drawing.Point(185, 240);
            this.btnBacktoHome4.Name = "btnBacktoHome4";
            this.btnBacktoHome4.Size = new System.Drawing.Size(109, 39);
            this.btnBacktoHome4.TabIndex = 6;
            this.btnBacktoHome4.Text = "Back to Home";
            this.btnBacktoHome4.UseVisualStyleBackColor = true;
            this.btnBacktoHome4.Click += new System.EventHandler(this.btnBacktoHome4_Click);
            // 
            // btnBacktoHome
            // 
            this.btnBacktoHome.Location = new System.Drawing.Point(185, 243);
            this.btnBacktoHome.Name = "btnBacktoHome";
            this.btnBacktoHome.Size = new System.Drawing.Size(138, 47);
            this.btnBacktoHome.TabIndex = 9;
            this.btnBacktoHome.Text = "Back to Home";
            this.btnBacktoHome.UseVisualStyleBackColor = true;
            this.btnBacktoHome.Click += new System.EventHandler(this.btnBacktoHome_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 355);
            this.Controls.Add(this.tab);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tab.ResumeLayout(false);
            this.tbHomePage.ResumeLayout(false);
            this.tbHomePage.PerformLayout();
            this.tbRectangle.ResumeLayout(false);
            this.tbRectangle.PerformLayout();
            this.tbTriangle.ResumeLayout(false);
            this.tbTriangle.PerformLayout();
            this.tbCircle.ResumeLayout(false);
            this.tbCircle.PerformLayout();
            this.tbHeronTri.ResumeLayout(false);
            this.tbHeronTri.PerformLayout();
            this.tbHelpPage.ResumeLayout(false);
            this.tbHelpPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tab;
        private System.Windows.Forms.TabPage tbHomePage;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button btnRectangleTab;
        private System.Windows.Forms.TabPage tbRectangle;
        private System.Windows.Forms.Button btnarea;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabPage tbTriangle;
        private System.Windows.Forms.TabPage tbCircle;
        private System.Windows.Forms.TabPage tbHeronTri;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lblLength;
        private System.Windows.Forms.Label lblWidth;
        private System.Windows.Forms.Button btnHelpFile;
        private System.Windows.Forms.Button btnHeronTriangleTab;
        private System.Windows.Forms.Button btnCircleTab;
        private System.Windows.Forms.Button btnTriangleTab;
        private System.Windows.Forms.Label lblChoice;
        private System.Windows.Forms.TabPage tbHelpPage;
        private System.Windows.Forms.Label lblTrianglPage;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblTriangleAns;
        private System.Windows.Forms.Label lblCirclePage;
        private System.Windows.Forms.Label lblRadius;
        private System.Windows.Forms.Label lblCircleTitle;
        private System.Windows.Forms.Button btnCalcCircle;
        private System.Windows.Forms.Label lblCircleAns;
        private System.Windows.Forms.TextBox txtbxRadius;
        private System.Windows.Forms.Label lblHrnLen3;
        private System.Windows.Forms.Label lblHrnLen2;
        private System.Windows.Forms.Label lblHrnLen1;
        private System.Windows.Forms.Label lblHrntriTitle;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button btnCalcHeron;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblStep3;
        private System.Windows.Forms.Label lblStep2;
        private System.Windows.Forms.Label lblStep1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStep4;
        private System.Windows.Forms.Button btnhome5;
        private System.Windows.Forms.Label lblans4;
        private System.Windows.Forms.Button btnbacktohome2;
        private System.Windows.Forms.Button btnBacktoHome3;
        private System.Windows.Forms.Button btnBacktoHome4;
        private System.Windows.Forms.Button btnBacktoHome;
    }
}

